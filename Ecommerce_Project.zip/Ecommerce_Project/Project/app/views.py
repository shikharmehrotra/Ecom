from django import apps
from django.http import Http404, HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import *
from .models import Customer
from django.core.exceptions import ObjectDoesNotExist
from django.contrib import auth
from django.contrib.auth.decorators import login_required
# Create your views here.
def arbitrary(request):
    return HttpResponse("ARBIT")

def home(request):
    
        return render(request,'app/home.html')

def register(request):
    if(request.method=='POST'):
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        email=request.POST['email']
        password=request.POST['password']
        phone=request.POST['phone']
        address=request.POST['address']
        try:
            u=User.objects.get(username=email.split('@')[0])
            return redirect('/login')
        except:
            try:
                user=User(username=email.split('@')[0],password=password,email=email)
                user.first_name=first_name
                user.last_name=last_name
                user.set_password(password)
                user.save()
                customer=Customer(user=user,phone=phone,address=address,name=first_name)
                customer.save()
                return render(request,'app/home.html',context={'first_name':first_name})
            except:
                return HttpResponse('User = '+email.split('@')[0]+' not exist')


    else:
        return render(request,'app/register.html')

def login(request):
    if(request.method=='POST'):
        username=request.POST['username']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if(user is not None):
            auth.login(request,user)
            return render(request,'app/home.html',context={'first_name':"Hello " + " "+username})
        else:
            return redirect('/register')
    else:
        return render(request,"app/login.html")


def logout(request):
    if(request.user.is_authenticated):
        auth.logout(request)
        return render(request,'app/logout.html')
    return redirect('/home')

def list_customer(request):
    if(request.user.is_authenticated):
        user=request.user
        if(user.is_superuser):
            customers=Customer.objects.all()
            return render(request,'app/customerList.html',context={'cust':customers})
        else:
            return HttpResponse("Authorization Error")
    else:
        return HttpResponse("Authentication Error")