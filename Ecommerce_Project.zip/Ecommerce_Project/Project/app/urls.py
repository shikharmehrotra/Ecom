from app import views
from django.urls import include, path
urlpatterns = [
    
    path('home',views.home),
    path('',views.home),
    path('hello/arbitrary',views.arbitrary),
    path('register',views.register),
    path('login',views.login),  
    path('logout',views.logout),
    path('lsd',views.logout),
    path('customerList',views.list_customer)
]