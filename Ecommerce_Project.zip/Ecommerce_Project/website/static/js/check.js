if(checkoutCartLength == 0)
{

    var html=document.getElementById("message_append");
    html.textContent="Admin You have done you Task !!!";

}
console.log(checkoutCartLength);

var s=document.getElementsByClassName("1");
            var f=document.getElementsByClassName("0");
            for(var i=0;i<s.length;i++)
            {
                s[i].addEventListener("click",function(){
                    var product=this.dataset.product;
                    var customer=this.dataset.user
                    var checkoutCartid=this.dataset.cart;
                    var url="/updOrderHistory";
                    fetch(url,{
                        method:"POST",
                        headers:{
                            "Content-Type":"application/json",
                            "X-CSRFToken":csrftoken
                        },
                        body:JSON.stringify({"productId":product,"customerId":customer,"status":"S","checkoutCart":checkoutCartid})
                    })
                    .then(res=>res.json())
                    .then(data=>{
                        var htmlTag=document.getElementById("checkoutCart"+checkoutCartid)
                    console.log(htmlTag)
                    htmlTag.remove()
                    });
                    
                })
            }
            for(var i=0;i<f.length;i++)
            {
                f[i].addEventListener("click",function(){
                    var product=this.dataset.product;
                    var customer=this.dataset.user;
                    var checkoutCartid=this.dataset.cart;
                    var url="/updOrderHistory";
                    fetch(url,{
                        method:"POST",
                        headers:{
                            "Content-Type":"application/json",
                            "X-CSRFToken":csrftoken
                        },
                        body:JSON.stringify({"productId":product,"customerId":customer,"checkoutCart":checkoutCartid,"status":"F"})
                    })
                    .then(res=>res.json())
                    .then(data=>{
                        console.log(data)
                    });
                    var htmlTag=document.getElementById("checkoutCart"+checkoutCartid)
                    console.log(htmlTag)
                    htmlTag.remove()
                })
            }