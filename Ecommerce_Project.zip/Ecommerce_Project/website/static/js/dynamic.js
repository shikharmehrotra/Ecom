var button=document.getElementsByClassName("btn btn-primary");
for(var i=0;i<button.length;i++){
    button[i].addEventListener('click',function(){

        var productId=this.dataset.product;
        

        var action=this.dataset.action;
        console.log("productId",productId,"action",action,"USER",user);
        
            updItem(productId,action);

    });

}
var checkout=document.getElementById("CHECKOUT");
checkout.addEventListener('click',function(){
    if(user=="AnonymousUser")
        {
            location.href="/login";
        }
        else
        {
            location.href="/checkout";
        }
});
function updItem(productId,action){
    var url="/update-item";
    fetch(url,
        {
            method:"POST",
            headers:{
                "Content-Type":"application/json",
                "X-CSRFToken":csrftoken
            },
            body:JSON.stringify({"productId":productId,"action":action})
        })
    .then(res=>{return res.json()})
    .then(res=>{
        var cartItemsHTML=document.getElementById("cart-quantity");
            cartItemsHTML.textContent=res.cart_items;
        if(res.Quantity=="0"){
            var rem=document.getElementById("div"+productId);
         
            rem.remove();
       
        }
        else{
            
            var htmlTag=document.getElementsByClassName(productId)[0];
            if(htmlTag!=null){
            htmlTag.textContent=res.Quantity;
            console.log(htmlTag,res.Quantity);
            }
            
                      
        }
        // console.log(htmlTag,res.Quantity,res);
    })
}