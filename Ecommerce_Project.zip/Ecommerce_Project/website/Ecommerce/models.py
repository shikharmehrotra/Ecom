from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Customer(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    address=models.TextField(max_length=500)
    phone=models.IntegerField(max_length=10)
    def __str__(self)->str:
        return self.user.first_name+"_"+self.user.last_name+"_"+str(self.id)

def file_name(instance,filename):
    return "/".join(["pics",filename])
class Product(models.Model):
    class Meta:
        permissions=(("idp","Can change id of not?"),)
    name=models.CharField(max_length=100)
    available=models.IntegerField()
    price=models.IntegerField()
    category=models.CharField(max_length=100)
    image=models.ImageField(upload_to=file_name)
    def __str__(self)->str:
        return self.name+"_"+str(self.id)

class Cart(models.Model):
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.IntegerField()
    def __str__(self)->str:
        return self.customer.user.first_name+"_"+self.product.name+"_"+str(self.id)

class OrderHistory(models.Model):
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.IntegerField()
    date=models.DateField()
    payment=models.CharField(max_length=100)
    delivery=models.CharField(max_length=5,default="P")
    ref_id=models.IntegerField(default=0)
    def __str__(self)->str:
        return self.customer.user.first_name+"_"+self.product.name+"_"+str(self.date)

class CheckoutCart(models.Model):
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.IntegerField()
    def __str__(self)->str:
        return self.customer.user.first_name+"_"+self.product.name+"_"+str(self.id)
    
