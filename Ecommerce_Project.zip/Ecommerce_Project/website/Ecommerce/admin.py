from django.contrib import admin

# Register your models here.
from Ecommerce.models import Customer,Product,Cart,OrderHistory,CheckoutCart

admin.site.register(Customer)
admin.site.register(Product)
admin.site.register(Cart)
admin.site.register(OrderHistory)
admin.site.register(CheckoutCart)
