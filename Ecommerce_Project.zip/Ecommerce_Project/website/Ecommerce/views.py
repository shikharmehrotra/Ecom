
from curses.ascii import HT
import datetime
from os import stat
import re
from urllib import response
from webbrowser import BaseBrowser
from django.http import HttpRequest, JsonResponse , HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User,Group
from . import models
from django.contrib import auth,messages
import json,random
import django.middleware
from django.core.files.storage import FileSystemStorage
# Create your views here.
def profileView(request):
    # print(request.session.get("KEY"))
    if(request.user.is_authenticated):
        user=request.user
        customer=models.Customer.objects.get(user=user)
        return render(request,"Ecommerce/profilePage.html",context={"customer":customer})
    else:
        return render(request,"Ecommerce/profilePage.html")
def addressChange(request):
    if(request.method=="GET"):
        customer=models.Customer.objects.get(user=request.user)
        return render(request,"Ecommerce/address.html",context={"addresss":customer.address})
    else:
        customer=models.Customer.objects.get(user=request.user)
        customer.address=request.POST["address"]
        customer.save()
        return redirect("/")
def changePassLogic(request):
    if(request.method=="POST"):
        if(request.user.is_authenticated):
            user=request.user
           
            old=request.POST["Old"]
            
            if user.check_password(old):
                new=request.POST["New"]
                confirm=request.POST["Confirm"]
                if(confirm==new):
                    user.set_password(new)
                    user.save()
                    admin=False
                    if(request.user.is_authenticated):
                        admin=request.user.groups.filter(name="admin").exists()
                    return render(request,"Ecommerce/ProductsList.html",context={"changePass":"Password change successfully","admin":admin})
                else:
                    return redirect("/passwordChange")
            return HttpResponse("invalid request")
        else:
            return redirect("log1in")
    return JsonResponse("Invalid Get Request",safe=False)
def passwordChange(request):
    if(request.user.is_authenticated):
        return render(request,"Ecommerce/changePassword.html")
    else:
        return redirect("log1in")
def updOrderHistory(request):
    if(request.method=="POST"):
        print(request.headers)
        data=json.loads(request.body)
        print(data)
        productId=data["productId"]
        customerId=data["customerId"]
        status=data["status"]
        checkoutCartid=data["checkoutCart"]
        product=models.Product.objects.get(id=productId)
        customer=models.Customer.objects.get(id=customerId)
        
        orderHistory=models.OrderHistory.objects.get(product=product,customer=customer,ref_id=checkoutCartid)
        
        orderHistory.delivery=status
        orderHistory.save()
        checkoutCart=models.CheckoutCart.objects.get(id=checkoutCartid)
        checkoutCart.delete()
        return JsonResponse("delivery status changing...",safe=False)
    else:
        return JsonResponse("Get Request Not Allowed",safe=False)
    # 
    pass
def updateCart(request):
    if(request.method=="POST" ):
        try:
            data=json.loads(request.body)
            if(data["status"]=="OK"):
                user=request.user
                customer=models.Customer.objects.get(user=user)
                Cart=list(models.Cart.objects.filter(customer=customer))
                for cart in Cart:
                    checkoutCart=models.CheckoutCart(customer=customer,product=cart.product,quantity=cart.quantity)
                    
                    product=cart.product
                    product.available=product.available-cart.quantity
                    product.save()
                    
                    checkoutCart.save()
                    orderHistory=models.OrderHistory(customer=customer,product=cart.product,quantity=cart.quantity,payment="ONLINE",date=datetime.datetime.now().date(),ref_id=checkoutCart.id)
                    orderHistory.save()
                    cart.delete()
                
                return JsonResponse({"Connection":"True"})
            else:
                return JsonResponse({"Connection":"False"})
        except:
            return JsonResponse("SOME ERROR",safe=False)
        return JsonResponse({"status":"YES"})
    return JsonResponse({"status":"NO"})
def adminView(request):
    
    user=request.user
    group=request.user.groups
    if(group.filter(name="admin").exists()):
        checkoutCart=list(models.CheckoutCart.objects.all())
        print(len(checkoutCart))
        return render(request,"Ecommerce/checkoutCart.html",context={"CheckoutCart":checkoutCart})
        pass
    else:
        return HttpResponse("Not Authorized")
def anonymous_cart(request):
    if("cart" in request.session):
        pass
    else:
        request.session["cart"]={}
    pass

def home(request):
    django.middleware.csrf.get_token(request)
    if("cart" in request.session):
        pass
    elif(not request.user.is_authenticated):
        request.session["cart"]={}
    # request.session["KEY"]=request.user.first_name
    # request.session.modified=True
    # request.session.get(key)
    # del request.session[key] for deleting data
    # request.session.items() [key,value]
    # request.session.flush() for deleting session
    print(request.user.has_perm("Ecommerce.idp"))
    admin=False
    total_cart_items=0
    if(request.user.is_authenticated):
        customer=models.Customer.objects.get(user=request.user)
        total_cart_items=len(models.Cart.objects.filter(customer=customer))
    else:
        total_cart_items=len(request.session["cart"])
    if(request.user.is_authenticated):
        admin=request.user.groups.filter(name="admin").exists()
    return render(request,'Ecommerce/ProductsList.html',context={"productDictionary":models.Product.objects.all(),"admin":admin,"cart_quantity":total_cart_items})
def call(request):
    return HttpResponse("Hello Welcome to call !!")

def registerAdmin(request):

    if(request.method=="GET"):
        return render(request,"Ecommerce/register.html")
    else:
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        password = request.POST['password']
        phone = request.POST['phone']
        address = request.POST['address']
        username=email.split('@')[0]
        group=Group.objects.get(name="admin")

        if(User.objects.filter(username=username).exists()):
            print("HERE")
            return redirect('login')
        else:
            user=User(first_name=first_name,last_name=last_name,email=email,username=username,password=password)
            user.set_password(password)
            user.save()
            user.groups.add(group)
            
            customer=models.Customer(user=user,address=address,phone=phone)
            customer.save()
            print("Hi")
            return render(request,'Ecommerce/base.html',context={"sendMessage":first_name })
        pass
def custom_group(request):
    grp="dhfvbhdbvdhvbhb"
    try:
        G=Group(name=grp)
        G.save()
    except:
        x=1
    return redirect("/login")
def product(request,pk):
    # print("##BODY##"+request.body)
    # print("##PATH##"+request.path)
    # print("##METHOD##"+request.method)
    # print("##COOKIES##"+request.COOKIES)
    # print("##META##"+request.META)
    # print("##FULL PATH##"+request.get_full_path())
    product=models.Product.objects.get(id=int(pk))
    
    return render(request,'Ecommerce/Product.html',context={"Product":product})
def listPermissions(request):
    userList=models.User.objects.all()
    print(request.user._meta.get_fields())
    print("########")
    print(request.user.has_perm("Ecommerce.idp"))
    print(request.user.user_permissions)
    return render(request,"Ecommerce/Perms.html")
def categoryView(request,category):
    categoryList=list(models.Product.objects.filter(category=category))
    print(len(categoryList))
    return render(request,"Ecommerce/category.html",context={"categoryList":categoryList,"category":category})
def register(request):
    if(request.user.is_authenticated):
        return redirect("/productList")
    if(request.method=="POST"):

        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        password = request.POST['password']
        phone = request.POST['phone']
        address = request.POST['address']
        username=email.split('@')[0]
        group=Group.objects.get(name="customer")

        if(User.objects.filter(username=username).exists()):
            print("HERE")
            return redirect('login')
        else:
            user=User(first_name=first_name,last_name=last_name,email=email,username=username,password=password)
            user.set_password(password)
            user.save()
            user.groups.add(group)
            
            customer=models.Customer(user=user,address=address,phone=phone)
            customer.save()
            print("Hi")
            return render(request,'Ecommerce/base.html',context={"sendMessage":first_name })
        
    else:
        return render(request,"Ecommerce/register.html")

def login(request):
    print(request.headers)
    if(request.user.is_authenticated):
        return redirect("/productList")
    if(request.method=="POST"):
        username=request.POST["username"]
        password=request.POST["password"]
        user=auth.authenticate(username=username,password=password)
        if(user is not None):
            auth.login(request,user)
            if("cart" in request.session):
                cart_=request.session["cart"]
                customer=models.Customer.objects.get(user=request.user)
                for pid,quantity in cart_.items():
                    product=models.Product.objects.get(pk=pid)
                    if(models.Cart.objects.filter(customer=customer,product=product).exists()):
                        cart=models.Cart.objects.get(customer=customer,product=product)
                        cart.quantity+=quantity
                        cart.save()
                    else:
                        cart=models.Cart(customer=customer,product=product,quantity=quantity)
                        cart.save()
                del request.session["cart"]
                
            # if("Referer" in request.headers):
            #     sender=request.headers["Referer"]
            #     host=request.headers["Host"]
            #     if("/cart"==sender.split(host)[1]):
            #         return redirect("/checkout")
            return redirect("/productList")
        else:
            return render(request,"Ecommerce/login.html")
    else:
        return render(request,"Ecommerce/login.html")
def logout(request):
    user=request.user
    # print(request.headers.keys())
    auth.logout(request)
    return redirect('home')

def ListProduct(request):
    if("cart" in request.session):
        pass
    elif(not request.user.is_authenticated):
        request.session["cart"]={}
    admin=False
    if(request.user.is_authenticated):
        admin=request.user.groups.filter(name="admin").exists()
    try:
        return render(request,"Ecommerce/ProductsList.html",context={"productDictionary":models.Product.objects.all(),"admin":admin,"cart_quantity":len(models.Cart.objects.filter(customer=models.Customer.objects.get(user=request.user)))})
    except:
        return render(request,"Ecommerce/ProductsList.html",context={"productDictionary":models.Product.objects.all(),"admin":admin,"cart_quantity":len(request.session["cart"])})
def ran(request):
    if(request.method=="POST"):
        return JsonResponse({"Connection":"True"})
    else:
        return JsonResponse({"Connection":"False"})
def updateItem(request):
    
    if(request.method=="POST" and request.user.is_authenticated ):
        print("HERE")
        data=json.loads(request.body)
        productId=data["productId"]
        action=data["action"]
        product=models.Product.objects.get(id=int(productId))
        mx_available=int(product.available)
        user=request.user
        customer=models.Customer.objects.get(user=user)

        if(action=="add"):
            if(models.Cart.objects.filter(customer=customer,product=product).exists()):
                cart=models.Cart.objects.get(customer=customer,product=product)
                if(cart.quantity+1<=mx_available):
                    cart.quantity+=1
                    cart.save()

            elif(mx_available>0):
                cart=models.Cart(customer=customer,product=product,quantity=1)
                cart.save()
            # return JsonResponse({"TransactionStatus":"OK","OrderId":"sdsd12991"})
            return JsonResponse({"Quantity":cart.quantity,"cart_items":len(models.Cart.objects.filter(customer=customer))})
        if(action=="remove" and models.Cart.objects.filter(customer=customer,product=product).exists()):
            cart=models.Cart.objects.get(customer=customer,product=product)
            if(cart.quantity>=1):
                cart.quantity-=1
                if(cart.quantity==0):
                    cart.delete()
                else:
                    cart.save()
            return JsonResponse({"Quantity":cart.quantity,"cart_items":len(models.Cart.objects.filter(customer=customer))})
        elif(action=="remove"):
            return JsonResponse({"Quantity":0,"cart_items":len(models.Cart.objects.filter(customer=customer))})
    elif((not request.user.is_authenticated) and (request.method=="POST")):
        data=json.loads(request.body)
        productId=data["productId"]
        action=data["action"]
        product=models.Product.objects.get(id=int(productId))
        mx_available=int(product.available)
        if(action=="add"):
            q=0
            if("cart" in request.session):
                if(str(productId) in request.session["cart"]):
                    if(request.session["cart"][str(productId)]+1<=mx_available):
                        request.session["cart"][str(productId)]+=1
                        request.session.modified=True
                        q=request.session["cart"][str(productId)]
                else:
                    if(mx_available>0):
                        request.session["cart"][str(productId)]=1
                        request.session.modified=True
                        q=1
            # return JsonResponse({"TransactionStatus":"OK","OrderId":"sdsd12991"})
            return JsonResponse({"Quantity":q,"cart_items":len(request.session["cart"])})
        if(action=="remove" and (str(productId) in request.session["cart"])):
            q=0
            if("cart" in request.session):
                if(str(productId) in request.session["cart"]):
                    if(request.session["cart"][str(productId)]-1>=0):
                        request.session["cart"][str(productId)]-=1
                        request.session.modified=True
                        q=request.session["cart"][str(productId)]
                        if(q==0):
                            del request.session["cart"][str(productId)]
                        request.session.modified=True
            # return JsonResponse({"TransactionStatus":"OK","OrderId":"sdsd12991"})
            return JsonResponse({"Quantity":q,"cart_items":len(request.session["cart"])})
        pass
    return JsonResponse({"Message":"Adding in Cart"})

def cart(request):
    if(request.user.is_authenticated):
        user=request.user
        customer=models.Customer.objects.get(user=user)
        cartProductList=models.Cart.objects.filter(customer=customer)
        
        return render(request,"Ecommerce/cart.html",context={"Cart":cartProductList,"cart_quantity":len(cartProductList)})
    else:
        # Cart modification------------
        productIDs=request.session["cart"]
        lst=[]
        for k,val in productIDs.items():
            quantity=val
            product=models.Product.objects.get(pk=int(k))
            dict={"product":product,"quantity":quantity}
            lst.append(dict)
        return render(request,"Ecommerce/cart.html",context={"cart_quantity":len(request.session["cart"]),"list":lst})
        return redirect("/login")
        # or return redirect("login-url-name")
def orderHistory(request):
    if(request.user.is_authenticated):
        order=list(models.OrderHistory.objects.filter(customer=models.Customer.objects.get(user=request.user)))
    
        return render(request,"Ecommerce/orderHistory.html",context={"orders":order,"customer":models.Customer.objects.get(user=request.user)})
    else:
        return redirect("log1in")
def checkout(request):
    print(request.headers)
    if(request.user.is_authenticated):

        customer=models.Customer.objects.get(user=request.user)

        productList=list(models.Cart.objects.filter(customer=customer))
        total_cost=0
        if(len(productList)==0):
            return redirect("ProductList")
        else:
            for cart_items in productList:
                total_cost+=(cart_items.product.price)*(cart_items.quantity)
            return render(request,"Ecommerce/payment-ops.html",{"total_cost":total_cost})
    else:
        return redirect("log1in")
def fakePayment(request):
    list=["OK","NO"]
    status=random.randint(0,10000000000)
    print(status)
    return JsonResponse({"status":list[0],"connection":"True"})
def payment(request):
    
    if(request.user.is_authenticated):
        return render(request,"Ecommerce/payment-page.html")
    return redirect("log1in")

def inventory(request):
    user=request.user
    grp=user.groups
    admin_group=Group.objects.get(name="admin")
    
    if(grp.filter(name="admin").exists()):
        if(request.method=="POST"):
            name=request.POST["name"]
            available=request.POST["available"]
            price=request.POST["price"]
            category=request.POST["category"]
            image=request.FILES["image"]
            print(image)
            # fss = FileSystemStorage()
            # file = fss.save(image.name, image)
            # file_url=fss.url(file)
            product=models.Product(name=name,available=available,price=price,category=category,image=image)
            product.save()
            print(request.POST)
            return redirect("log1in")
            pass
        else:    
            return render(request,"Ecommerce/inventory.html",context={"Connection":"True"})
    return HttpResponse(status=404)
    pass

# Cookies
# Cookies are piece of data that is feeded/set into the client machine's browser
# Once the cookies have been set cookies can be accessed by the server whenever any request has been made until it expires.
# HttpResponse.set_cookie(key,value,path="/",domain="",max_age=(number of seconds),expires=date,httponly=True (prevent cookies accessed 
# by client-side javascript))
# request.COOKIES.get(key)
# response.set_signed_cookie(same as above,salt="")
# request.get_signed_cookie(key,salt="")

# #Client side rendering
# 1>Server send response to browser
# 2>Browser downloads js
# 3>executes react
# 4>page is now interactive and viewable

# #Server side rendering
# 1>Server send response including the ready rendered HTML to BaseBrowser
# 2>Page rendering making it viewable
# 3>execute react
# 4>page is now interactive

# SSR initial render is faster because in SSR the ready render html is sent as response but in CSR more JS is downloaded and 
# requiring 2nd http request to load content and more JS to generate template

#Session Framework
# Cookies contain sessionID improving security of data by not exposing cookie manipulation in client-side 
# django.contrib.sessions and django.contrib.sessions.middleware.SessionMiddleware
# request.session[key]=value
# request.session.get(key)
# del request.session[key] for deleting data
# request.session.items() [key,value]
# request.session.flush() for deleting session
 


 