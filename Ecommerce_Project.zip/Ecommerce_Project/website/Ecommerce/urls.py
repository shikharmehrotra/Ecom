from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from . import views
urlpatterns = [
    path('',views.home,name="home"),
    path('register',views.register,name="register"),
    path('profileView',views.profileView,name="profileView"),
    path('login',views.login,name="log1in"),
    path("passwordChange",views.passwordChange,name="changePassword"),
    path("changePassLogic",views.changePassLogic,name="changePassLogic"),
    path('logout',views.logout,name="logout"),
    path('productList',views.ListProduct,name="ProductList"),
    path('product/<int:pk>',views.product,name="ProductView"),
    path('product/<str:category>',views.categoryView,name="CategoryView"),
    path('cart',views.cart,name="cart"),
     path('update-item',views.updateItem,name="updItem"),
     path('checkout',views.checkout,name="checkout"),
     path('payment-page',views.payment,name="payment-page"),
     path("fake-payment-api",views.fakePayment,name="fake-payment-api"),
     path("group-add",views.custom_group,name="sd"),
     path("permList",views.listPermissions,name="PermsList"),
     path("adminReg",views.registerAdmin,name="adminReg"),
     path("inventory",views.inventory,name="inventory"),
     path("ran",views.ran),
     path("checkoutCart",views.adminView),
     path("updateCart",views.updateCart),
     path("orderHistory",views.orderHistory),
     path("updOrderHistory",views.updOrderHistory),
     path("addressChange",views.addressChange,name="addressChange")
]